############################## Phonebook Directory ##########################
# Created by: Mihirkumar Dilipbhai Patel, Faiyaz Sattar, MD Nurul Afsar Zahid 



from tkinter import *
# importing submodule of tkinter (ttk)  for using more styles for GUI
from tkinter import ttk

from displays import *
from tkinter import messagebox

# colours used in GUI
cream_colour = "#FFE4B5"
white_colour = "#ffffff"
red_colour = "#FF0000"


#
window = Tk()
window.title ("")
window.geometry('488x450')
window.configure(background=cream_colour)
window.resizable(width=FALSE, height=FALSE)

#frames
frame_up = Frame(window, width=500, height=50, background=red_colour)
frame_up.grid(row=0, column=0, padx=0, pady=1)

frame_down = Frame(window, width=500, height=150, background=cream_colour)
frame_down.grid(row=1, column=0, padx=0, pady=1)

frame_table = Frame(window, width=500, height=100, background=cream_colour, relief="flat")
frame_table.grid(row=2, column=0, columnspan=2, padx=10, pady=1, sticky=NW)

#functions
def show():
    global tree

    list_header = ['Name', 'Gender', 'Telephone', 'Email']

    phonebook_list = display()

    tree = ttk.Treeview(frame_table, selectmode="extended", columns=list_header, show="headings")

    vsb = ttk.Scrollbar(frame_table, orient="vertical", command=tree.yview)
    hsb = ttk.Scrollbar(frame_table, orient="horizontal", command=tree.xview)

    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

    tree.grid(column=0, row=0, sticky='nsew')
    vsb.grid(column=1, row=0, sticky='ns')
    hsb.grid(column=0, row=1, sticky='ew')

    #tree head
    tree.heading(0, text=' Name', anchor=NW)
    tree.heading(1, text='Gender', anchor=NW)
    tree.heading(2, text='Telephone', anchor=NW)
    tree.heading(3, text='Email', anchor=NW)

    # tree  columns
    tree.column(0, width=120, anchor='nw')
    tree.column(1, width=50, anchor='nw')
    tree.column(2, width=100, anchor='nw')
    tree.column(3, width=180, anchor='nw')

    for item in phonebook_list:
        tree.insert('', 'end', values=item)

show()

def insert():
    Name = name.get()
    Gender = gender.get()
    Telephone = telephone.get()
    Email = email.get()

    data = [Name, Gender, Telephone, Email]

    if Name == '' or Gender == '' or Telephone == '' or Email == '':
        messagebox.showwarning('data', 'Please fill up all the fields provided!')
    
    else:
        add(data)
        messagebox.showinfo('data', 'Information has been added successfully')

        name.delete(0, 'end')
        gender.delete(0, 'end')
        telephone.delete(0, 'end')
        email.delete(0, 'end')

        show()

def to_update():
    
    try:
        tree_data = tree.focus()
        tree_dictionary = tree.item(tree_data)
        tree_list = tree_dictionary['values']

        Name = str(tree_list[0])
        Gender = str(tree_list[1])
        Telephone = str(tree_list[2])
        Email = str(tree_list[3])

        name.insert(0, Name)
        gender.insert(0, Gender)
        telephone.insert(0, Telephone)
        email.insert(0, Email)

        def confirm():
            new_name = name.get()
            new_gender = gender.get()
            new_telephone = telephone.get()
            new_email = email.get()

            data = [new_telephone, new_name, new_gender, new_telephone, new_email]

            update(data)

            messagebox.showinfo('Success', 'Information has been updated successfully')

            name.delete(0, 'end')
            gender.delete(0, 'end')
            telephone.delete(0, 'end')
            email.delete(0, 'end')

            for widget in frame_table.winfo_children():
                widget.destroy()

            b_confirm.destroy()

            show()
            
        b_confirm =  Button(frame_down, text="Confirm", width=10, height=1, background=red_colour, foreground = cream_colour, font=('Ivy 8 bold'), command=confirm)
        b_confirm.place(x = 290, y = 110)

    except IndexError:
        messagebox.showerror('Error!!', 'Select one of them from the table')

def to_remove():
    try:
        tree_data = tree.focus()
        tree_dictionary = tree.item(tree_data)
        tree_list = tree_dictionary['values']
        tree_telephone = str(tree_list[2])

        remove(tree_telephone)

        messagebox.showinfo('Success', 'Information has been deleted successfully')

        for widget in frame_table.winfo_children():
            widget.destroy()
        show()

    except IndexError:
        messagebox.showerror('Error!!', 'Select one of them from the table')

def to_search():
    telephone = e_search.get()

    data = search(telephone)

    def delete_command():
        tree.delete(*tree.get_children())

    delete_command()

    for item in data:
        tree.insert('', 'end', values = item)
        
    e_search.delete(0, 'end')

#frame_up widgets

app_name = Label(frame_up, text="Phonebook Directory", height = 1, font=('Verdana 17 bold'), background = red_colour, fg = cream_colour)
app_name.place(x=5, y=5)

#frame_down widgets
l_name = Label(frame_down, text="Name *", width=20, height=1, font=('Times 10 bold'), background=cream_colour, anchor=NW)
l_name.place(x=10, y=20)
name = Entry(frame_down, width=25, justify='left', highlightthickness=1, relief="solid")
name.place(x=80, y=20)

l_gender = Label(frame_down, text="Gender *", width=20, height=1, font=('Times 10 bold'), background=cream_colour, anchor=NW)
l_gender.place(x=10, y=50)
gender = ttk.Combobox(frame_down, width=27)
gender['values'] = ['', 'Female', 'Male'] 
gender.place(x=80, y=50)

l_telephone = Label(frame_down, text="Telephone*", height=1, font=('Times 10 bold'), background=cream_colour, anchor=NW)
l_telephone.place(x=10, y=80)
telephone = Entry(frame_down, width=25, justify='left', highlightthickness=1, relief="solid")
telephone.place(x=80, y=80)

l_email = Label(frame_down, text="Email *", height=1, font=('Times 10 bold'), background=cream_colour, anchor=NW)
l_email.place(x=10, y=110)
email = Entry(frame_down, width=25, justify='left', highlightthickness=1, relief="solid")
email.place(x=80, y=110)

b_search = Button(frame_down, text="Search", height=1, background=red_colour, foreground = cream_colour,font=('Ivy 8 bold'), command=to_search)
b_search.place(x=290, y=20)
e_search = Entry(frame_down, width=16, justify='left', font=('Ivy', 11), highlightthickness=1, relief="solid")
e_search.place(x=347, y=20)

b_view = Button(frame_down, text="Display", width=10, height=1, background=red_colour, foreground = cream_colour,font=('Ivy 8 bold'), command = show)
b_view.place(x=290, y=50)

b_add = Button(frame_down, text="Add", width=10, height=1, background=red_colour, foreground = cream_colour,font=('Ivy 8 bold'), command=insert)
b_add.place(x=400, y=50)

b_update = Button(frame_down, text="Update", width=10, height=1, background=red_colour, foreground = cream_colour,font=('Ivy 8 bold'), command=to_update)
b_update.place(x=400, y=80)

b_delete = Button(frame_down, text="Delete", width=10, height=1, background=red_colour, foreground = cream_colour,font=('Ivy 8 bold'), command = to_remove)
b_delete.place(x=400, y=110)


window.mainloop()

