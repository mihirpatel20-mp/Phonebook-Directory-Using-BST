############################## Phonebook Directory ##########################
# Created by: Mihirkumar Dilipbhai Patel



from asyncore import write
import re
import sys
import csv
class BSTNode:
    def __init__(i, val=None):
        i.left = None
        i.right = None
        i.val = val
        
    

def add(i):
    def insert(self, val):
        if not self.val:
            self.val = val
            return
        if self.val == val:
            return
        if val < self.val:
            if self.left:
                self.left.insert(val)
                return
            self.left = BSTNode(val)
            return
        if self.right:
            self.right.insert(val)
            return
        self.right = BSTNode(val)
    
    
    with open('data.csv','a+', newline ='') as file:
        writer = csv.writer(file)
        writer.writerow(i)

def display():
    def find_index(elements, value):
        left, right = 0, len(elements) - 1
        while left <= right:
            middle = (left + right) // 2
            if elements[middle] == value:
                return middle
            if elements[middle] < value:
                left = middle + 1
            elif elements[middle] > value:
                right = middle - 1
    
    data = []
    with open('data.csv') as file:
        reader = csv.reader(file)
        for row in reader:
            data.append(row)
    print(data)
    return data
    

def remove(i):
    def save(j):
        def delete_Node(root, key):
            # if root doesn't exist, just return it
            if not root:
                return root
            # Find the node in the left subtree	if key value is less than root value
            if root.val > key:
                root.left = delete_Node(root.left, key)
                # Find the node in right subtree if key value is greater than root value,
            elif root.val < key:
                    root.right= delete_Node(root.right, key)
                    # Delete the node if root.value == key
            else:
                        # If there is no right children delete the node and new root would be root.left
                        if not root.right:
                            return root.left
                        # If there is no left children delete the node and new root would be root.right
                        if not root.left:
                            return root.right
                        # If both left and right children exist in the node replace its value with
                        # the minmimum value in the right subtree. Now delete that minimum node
                        # in the right subtree
                        temp_val = root.right
                        mini_val = temp_val.val
                        while temp_val.left:
                            temp_val = temp_val.left
                            mini_val = temp_val.val
                            # Delete the minimum node in right subtree
                            root.right = deleteNode(root.right,root.val)
                            return root
        with open('data.csv', 'w', newline= '') as file:
            writer = csv.writer(file)
            writer.writerows(j)
            
    new_list = []
    telephone = i
    
    with open('data.csv') as file:
        reader = csv.reader(file)
        for row in reader:
            new_list.append(row)
            for element in row:
                if element == telephone:
                    new_list.remove(row)
    save(new_list)
    

    
def update(i):
    def update_newlist(j):
        with open('data.csv','w',newline='') as file:
            writer = csv.writer(file)
            writer.writerows(j)
    new_list = []
    telephone = i[0]
    with open('data.csv','r') as file:
        reader = csv.reader(file)
        for row in reader:
            new_list.append(row)
            for element in row:
                if element == telephone:
                    name = i[1]
                    gender = i[2]
                    telephone = i[3]
                    email = i[4]
                    data = [name, gender, telephone, email]
                    index = new_list.index(row)
                    new_list[index] = data
    update_newlist(new_list)
    

    
def search(i):
    def find_index(i, value):
        left, right = 0, len(elements) - 1
        while left <= right:
            middle = (left + right) // 2
        if i[middle] == value:
            return middle

        if i[middle] < value:
            left = middle + 1
        elif i[middle] > value:
            right = middle - 1
    data = []
    telephone = i
    
    with open('data.csv','r') as file:
        reader = csv.reader(file)
        for row in reader:
            for element in row:
                if element == telephone:
                    data.append(row)
    print(data)
    return data
